import psycopg2

import os

host = os.environ['POSTGRES_HOST']
port = os.environ['POSTGRES_PORT']
user = os.environ['POSTGRES_USER']
password = os.environ['POSTGRES_PASSWORD']
database = os.environ['POSTGRES_DB']

def retreive_data():
    try:
        conn = psycopg2.connect(
            host=host,
            port=port,
            database=database,
            user=user,
            password=password
        )

        cursor = conn.cursor()

        select_query = "SELECT validation, phone_number FROM user_data"
        cursor.execute(select_query)


        result_dict = {}
        rows = cursor.fetchall()
        for row in rows:
            validation, phone_number = row
            result_dict[phone_number] = validation

        return result_dict
    except (psycopg2.Error, Exception) as error:
        print("Error while connecting to PostgreSQL:", error)
    finally:
        # Close the database connection
        if cursor:
            cursor.close()
        if conn:
            conn.close()

    return None




def select_num():
    try:
        conn = psycopg2.connect(
            host=host,
            port=port,
            database=database,
            user=user,
            password=password
        )

        cursor = conn.cursor()

        select_query = "SELECT phone_id, phone_number FROM phones_num WHERE available = 'available' LIMIT 1"
        cursor.execute(select_query)

        row = cursor.fetchone()
        if row:
            phone_id, phone_number = row

            update_query = "UPDATE phones_num SET available = 'filled' WHERE phone_id = %s"
            cursor.execute(update_query, (phone_id,))
            conn.commit()

            print(phone_number)
            return row[1]
        else:
            print("No available phone numbers.")
    except (psycopg2.Error, Exception) as error:
        print("Error while connecting to PostgreSQL:", error)
    finally:
        # Close the database connection
        if cursor:
            cursor.close()
        if conn:
            conn.close()

    return None

def update_validation(phone):
    try:
        conn = psycopg2.connect(
            host=host,
            port=port,
            database=database,
            user=user,
            password=password
        )

        cursor = conn.cursor()

        update_query = "UPDATE user_data SET validation = 'done' Where phone_number = %s"
        cursor.execute(update_query, (phone,))
        conn.commit()

    except (psycopg2.Error, Exception) as error:
        print("Error while connecting to PostgreSQL:", error)
    finally:
        # Close the database connection
        if cursor:
            cursor.close()
        if conn:
            conn.close()

    return None

def check_list(phone_num):
    v_list = retreive_data()
    for phone in v_list:
        if v_list[phone] == 'pending':
            phone = select_num()
            update_validation(phone_num)
            return phone