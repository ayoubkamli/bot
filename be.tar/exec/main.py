from fastapi import FastAPI, Request
import requests
import json
from data import *

app = FastAPI()

token = "EAANlrWnMvoQBAOkbiDHkfXrFLyXVabYEZCRSeyTUhABuwa7f5L09Hf2WLYKG4pwsoEZALmZAFzgcYPSgP0cdKLgpulzHe0tQSqrmvD40g2awxKmRZCf2Xu1ZBXtBto8hh716Lc2if16ONK1MAdHgWsUrB8iTw1hInhwlXFREhI1f6nCtZB1LP4pZA92X7vlQ7stSUogVxPEtmzJqZCDvrUOU"
my_token = "soulaimane"

@app.get("/webhook")
def verify_webhook(request: Request):
    mode = request.query_params.get('hub.mode')
    challenge = request.query_params.get('hub.challenge')
    token = request.query_params.get('hub.verify_token')

    if mode and token:
        if mode == "subscribe" and token == my_token:
            return challenge
        else:
            return "Forbidden", 403

@app.post("/webhook")
def receive_webhook(request: Request, body):
    body_param = request.json()

    print(json.dumps(body_param, indent=2))

    if body_param.get('object'):
        entry = body_param['entry'][0]
        if 'change' in entry and 'value' in entry['change'][0] and 'messages' in entry['change'][0]['value']:
            phone_no_id = entry['change'][0]['value']['metadata']['phone_number_id']
            from_number = entry['change'][0]['value']['messages'][0]['from']
            msg_body = entry['change'][0]['value']['messages'][0]['text']['body']

            retreive_data(phone_no_id)

            if body=='':
                payload = {
                    "messaging_product": "whatsapp",
                    "to": from_number,
                    "text": {
                        "body": message(phone_no_id, msg_body)
                    }
                }
            else :
                payload = {
                    "messaging_product": "whatsapp",
                    "to": from_number,
                    "text": {
                        "body": message(phone_no_id, msg_body)
                    }
                }
            
            url = f"https://graph.facebook.com/v16.0/{phone_no_id}/messages?access_token={token}"
            headers = {
                "Content-Type": "application/json"
            }
            response = requests.post(url, json=payload, headers=headers)

            if response.status_code == 200:
                return "OK"
            else:
                return "Forbidden", 403
        else:
            return "Forbidden", 403

#message counter
def message(phone_no_id, msg_body):
    # connect to psycopg
    counter, id_counter = retreive_data(phone_no_id)
    update_counter(id_counter, counter)
    if counter == 1:
        return 'Hello welcome to Bi biscuit \n can you please insert your name'
    if counter == 2:
        insert_name(phone_no_id, msg_body)
        return 'can you please send us video link'
    if counter == 3:
        insert_link(phone_no_id, msg_body)
        return "thanks for your participation once we're done processing the information you provided us we will send you the number"
    else:
        return "wait for our answer please"


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)