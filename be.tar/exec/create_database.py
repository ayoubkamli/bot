import psycopg2
import os

host = os.environ['POSTGRES_HOST']
port = os.environ['POSTGRES_PORT']
user = os.environ['POSTGRES_USER']
password = os.environ['POSTGRES_PASSWORD']
database = os.environ['POSTGRES_DB']

print("fdqsdqs", host)

# Connect to the PostgreSQL server
conn = psycopg2.connect(
    host=host,
    port=port,
    database=database,
    user=user,
    password=password
)

# Create a database
def create_database():
    # Connect to the default database
    conn.autocommit = True
    default_conn = psycopg2.connect(
        host=host,
        port=port,
        user=user,
        password=password
    )
    default_cursor = default_conn.cursor()

    # Create the new database
    default_cursor.execute(f"CREATE DATABASE {database}")
    print(f"Database '{database}' created successfully")

    # Close the connection to the default database
    default_cursor.close()
    default_conn.close()

# Create tables in the database
def create_tables():
    cursor = conn.cursor()

    # Create the first table
    create_table_query = """
        CREATE TABLE IF NOT EXISTS public.counter
        (
            id_user integer NOT NULL,
            counter integer
        )
    """
    cursor.execute(create_table_query)
    print("Table 'table1' created successfully")

    # Create the second table
    create_table_query = """
        CREATE TABLE IF NOT EXISTS public.logs
        (
            id integer NOT NULL,
            timestamp_send integer,
            timestamp_received integer,
            message character(1) COLLATE pg_catalog."default"
        )
    """
    cursor.execute(create_table_query)
    print("Table 'table2' created successfully")

        # Create the second table
    create_table_query = """
        CREATE TABLE IF NOT EXISTS public.phones_num
        (
            phone_id integer NOT NULL,
            phone_number integer NOT NULL,
            available character(200) COLLATE pg_catalog."default",
            CONSTRAINT phones_num_pkey PRIMARY KEY (phone_id)
        )
    """
    cursor.execute(create_table_query)
    print("Table 'table3' created successfully")


    # Create the second table
    create_table_query = """
        CREATE TABLE IF NOT EXISTS public.user_data
        (
            "ID" integer NOT NULL DEFAULT 0,
            name character(200) COLLATE pg_catalog."default" NOT NULL,
            phone_number integer NOT NULL,
            link character(500) COLLATE pg_catalog."default",
            validation character(200) COLLATE pg_catalog."default" NOT NULL DEFAULT 0,
            CONSTRAINT user_data_pkey PRIMARY KEY ("ID")
        )
    """
    cursor.execute(create_table_query)
    print("Table 'table4' created successfully")


    # Commit the changes and close the cursor
    conn.commit()
    cursor.close()

# Call the functions to create the database and tables
create_database()
create_tables()

# Close the connection to the PostgreSQL server
conn.close()