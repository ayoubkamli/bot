import psycopg2
import os

host = os.environ['POSTGRES_HOST']
port = os.environ['POSTGRES_PORT']
user = os.environ['POSTGRES_USER']
password = os.environ['POSTGRES_PASSWORD']
database = os.environ['POSTGRES_DB']

# database connection
def update_counter(id_counter, counter):
    conn = psycopg2.connect(
        host=host,
        port=port,
        database=database,
        user=user,
        password=password
    )
    cursor = conn.cursor()

    update_query = "UPDATE counter SET counter = %s WHERE id_user = %s"
    cursor.execute(update_query, (int(counter)+1, id_counter))
    conn.commit()

def insert_name(phone_no_id, msg_body):
    conn = psycopg2.connect(
        host=host,
        port=port,
        database=database,
        user=user,
        password=password
    )
    cursor = conn.cursor()

    update_query = "UPDATE user_data SET name = %s WHERE phone_number = %s"
    cursor.execute(update_query, (msg_body,phone_no_id))
    conn.commit()

def insert_link(phone_no_id, msg_body):
    conn = psycopg2.connect(
        host=host,
        port=port,
        database=database,
        user=user,
        password=password
    )
    cursor = conn.cursor()

    update_query = "UPDATE user_data SET link = %s WHERE phone_number = %s"
    cursor.execute(update_query, (msg_body,phone_no_id))
    conn.commit()

def retreive_data(phone):
    conn = psycopg2.connect(
        host=host,
        port=port,
        database=database,
        user=user,
        password=password
    )

    cursor = conn.cursor()

    select_query = "SELECT * FROM user_data WHERE phone_number = %s"

    cursor.execute(select_query, (phone,))

    existing_row = cursor.fetchone()
    if existing_row:
        select_query = "SELECT counter FROM counter WHERE ID = %s"
        cursor.execute(select_query, (existing_row['id'],))
        return cursor.fetchone()[0], existing_row['id']
    
    else:
        # Phone number doesn't exist, perform the INSERT operation
        insert_query = "INSERT INTO user_data (ID, phone_number, validation) VALUES (%s, %s, %s)"
        data = (phone, 0, "pending")
        cursor.execute(insert_query, data)
        inserted_id = cursor.fetchone()[0]
        conn.commit()
        insert_query = "INSERT INTO counter (id_user, counter) VALUES (%s, %s)"
        data = (inserted_id, 0)
        cursor.execute(inserted_id, data)
        return 0
    
# message=approved or refused
def update_validation(phone_no_id, message):
    conn = psycopg2.connect(
        host=host,
        port=port,
        database=database,
        user=user,
        password=password
    )
    cursor = conn.cursor()

    update_query = "UPDATE user_data SET validation = %s WHERE phone_number = %s"
    cursor.execute(update_query, (message,phone_no_id))
    conn.commit()