from fastapi import FastAPI
from data import update_validation
from auto import check_list
import requests

app = FastAPI()

@app.post("/confirm")
async def receive_confirm(phone:int, message):
        print("yes")
        update_validation(phone, message)
        phone_available = check_list(phone)
        return phone_available


def send_post_request(url, body):
    try:
        url = "https://localhost:8000/webhook"
        response = requests.post(url, json=body)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as error:
        print("Error occurred during the request:", error)
        return None
    
# body need to be filled with the new phone number
    
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)